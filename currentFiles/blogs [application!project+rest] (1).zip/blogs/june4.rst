Wednesday, June 4th
====================


Finished up the initial update of the *requirments.txt* file this morning. Committed it to my forked github repo. Now I just need to work on getting VS 2010 installed and working correctly so that I can install all the packages that depend on it. I've email Ben with this issue and he is getting it sorted out. (Hopefully)

Now I am just studying up on porting python from 2-3. Some useful links I found.

- `Guide to Python 3 Porting <http://techspot.zzzeek.org/2011/01/24/zzzeek-s-guide-to-python-3-porting/>`_.
- `Guido's Own Guide <https://docs.python.org/release/3.0.1/whatsnew/3.0.html>`_.
- `Supporting Python 2 and 3 without 2to3 conversion <http://python3porting.com/noconv.html>`_.

