First Day
=========

So this is my first day at TMR.

I am using a virtual desktop and just have a thin client on my desk. Today I have been installing software and getting my environment ready.
Software I have installed includes

- Git for Windows (with .NET dependencies)
- Python2.7
- Python3.4
- VIM
- Virtualenv
